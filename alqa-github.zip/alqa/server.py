#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Alqa — Онлайн білім бағалау: интернетсіз жергілікті сервер.
Тек Python стандартты кітапханасы қолданылады (қосымша орнату қажет емес).

Іске қосу:   python server.py            (порт 8000)
             python server.py 8080       (басқа порт)
             python server.py --reset-admin   (әкімшінің жаңа уақытша парольін жасау)
Деректер:    осы бумадағы alqa.db файлында сақталады (көшірмесін сақтап қойыңыз).

Қосымша баптаулар (орта айнымалылары, міндетті емес):
  PORT                  сервер порты (әдепкі 8000)
  ALQA_HOST             тыңдайтын адрес (әдепкі 0.0.0.0)
  ALQA_DB               дерекқор файлының жолы (әдепкі: server.py жанындағы alqa.db)
  ALQA_ADMIN_PASSWORD   алғашқы әкімші паролі (берілмесе, кездейсоқ жасалып, терезеде көрсетіледі)
"""
import os, sys, json, sqlite3, secrets, hashlib, hmac, uuid, time, socket, traceback, random
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from datetime import datetime, timezone

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get('ALQA_DB') or os.path.join(BASE, 'alqa.db')
FIRST_RUN_ADMIN_PW = None  # бірінші іске қосуда кездейсоқ жасалған пароль
INDEX = os.path.join(BASE, 'index.html')
GRADES = tuple('%d-сынып' % n for n in range(2, 12))  # 2-сынып ... 11-сынып
DEFAULT_SUBJECTS = (('math', 'Математикалық сауаттылық', 'Математика'),
                    ('reading', 'Оқу сауаттылығы', 'Оқу'),
                    ('science', 'Жаратылыстану сауаттылығы', 'Жаратылыстану'))
MAX_SUBJECTS = 20
RNG = random.SystemRandom()
PW_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'
ITER = 150000
SESSION_DAYS = 7


class ApiError(Exception):
    pass


# ------------------------------------------------------------------ DB
def connect():
    db = sqlite3.connect(DB_PATH, timeout=20)
    db.row_factory = sqlite3.Row
    db.execute('pragma foreign_keys = on')
    return db


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def hash_pw(pw):
    salt = os.urandom(16)
    h = hashlib.pbkdf2_hmac('sha256', pw.encode('utf-8'), salt, ITER)
    return 'pbkdf2$%d$%s$%s' % (ITER, salt.hex(), h.hex())


def check_pw(pw, stored):
    try:
        _, it, salt, h = stored.split('$')
        calc = hashlib.pbkdf2_hmac('sha256', pw.encode('utf-8'), bytes.fromhex(salt), int(it))
        return hmac.compare_digest(calc.hex(), h)
    except Exception:
        return False


def gen_pw():
    return ''.join(secrets.choice(PW_ALPHABET) for _ in range(8))


SEED_Q = [
    ('math', 'Дүкенде 1 кг алманың бағасы 600 теңге. 2,5 кг алма қанша тұрады?', ['1200 теңге', '1500 теңге', '1800 теңге', '1650 теңге'], 1),
    ('math', 'Сыныпта 30 оқушы бар, олардың 40%-ы қыздар. Сыныпта неше қыз бар?', ['10', '12', '15', '18'], 1),
    ('math', 'Тіктөртбұрыштың ұзындығы 8 см, ені 5 см. Оның периметрі қанша?', ['13 см', '26 см', '40 см', '30 см'], 1),
    ('math', 'Автобус 60 км/сағ жылдамдықпен 3 сағат жүрді. Ол қанша қашықтық жүріп өтті?', ['180 км', '120 км', '63 км', '20 км'], 0),
    ('math', '3/4 және 0,5 сандарының қосындысы қандай?', ['1,15', '1,25', '1,5', '0,8'], 1),
    ('reading', '«Абай жолы» романының авторы кім?', ['Мұхтар Әуезов', 'Сәбит Мұқанов', 'Ілияс Есенберлин', 'Әбдіжәміл Нұрпейісов'], 0),
    ('reading', 'Мәтін: «Күз келді. Ағаштардың жапырақтары сарғайып, жерге түсе бастады. Құстар жылы жаққа ұшты.» Мәтін қай жыл мезгілі туралы?', ['Көктем', 'Жаз', 'Күз', 'Қыс'], 2),
    ('reading', '«Еңбек етсең — емерсің» мақалының мағынасы қандай?', ['Ештеңе істемеген жақсы', 'Еңбек ету нәтиже береді', 'Тамақты көп ішу керек', 'Ертерек ұйықтау керек'], 1),
    ('reading', '«Қуану» сөзінің синонимін табыңыз.', ['Қайғыру', 'Шаттану', 'Ашулану', 'Жылау'], 1),
    ('reading', '«Үлкен» сөзінің антонимін табыңыз.', ['Биік', 'Кіші', 'Ұзын', 'Жуан'], 1),
    ('science', 'Қалыпты қысымда судың қайнау температурасы қандай?', ['50 °C', '80 °C', '100 °C', '120 °C'], 2),
    ('science', 'Өсімдіктер фотосинтез кезінде қандай газды сіңіреді?', ['Оттегі', 'Көміртек (IV) оксиді', 'Азот', 'Сутек'], 1),
    ('science', 'Күн жүйесіндегі ең үлкен планета қайсы?', ['Жер', 'Марс', 'Юпитер', 'Сатурн'], 2),
    ('science', 'Адам денесінде қанды айдайтын мүше қайсы?', ['Өкпе', 'Бауыр', 'Жүрек', 'Бүйрек'], 2),
    ('science', 'Магнит қандай металды тартады?', ['Алюминий', 'Темір', 'Мыс', 'Алтын'], 1),
]


def init_db():
    db = connect()
    db.execute('pragma journal_mode = wal')
    with db:
        db.executescript('''
        create table if not exists users(
          id text primary key, name text not null, school text not null default '',
          grade text not null default '', login text not null, pw_hash text not null,
          role text not null default 'student', status text not null default 'active',
          must_change integer not null default 0, created_at text not null);
        create unique index if not exists users_login on users(lower(login));
        create table if not exists sessions(
          token text primary key, user_id text not null references users(id) on delete cascade,
          expires_at real not null);
        create table if not exists questions(
          seq integer primary key autoincrement, id text unique not null, subject text not null,
          text text not null, options text not null, correct integer not null);
        create table if not exists attempts(
          id text primary key, user_id text not null references users(id) on delete cascade,
          started_at real not null, duration_min integer not null, questions text not null,
          submitted integer not null default 0);
        create table if not exists results(
          id text primary key, user_id text references users(id) on delete set null,
          name text not null, school text not null default '', grade text not null default '',
          score integer not null, total integer not null, pct integer not null,
          time_sec integer not null, subjects text not null, created_at text not null);
        create table if not exists subjects(
          key text primary key, name text not null, short text not null, pos integer not null);
        create table if not exists settings(key text primary key, value text not null);
        create table if not exists login_fails(id integer primary key autoincrement, login text not null, at real not null);
        ''')
        db.execute("insert or ignore into settings(key,value) values('duration','15')")
        if not db.execute('select 1 from subjects').fetchone():
            saved = {}
            try:
                r = db.execute("select value from settings where key='subjects'").fetchone()
                saved = json.loads(r['value']) if r else {}
            except Exception:
                saved = {}
            for i, (k, n, sh) in enumerate(DEFAULT_SUBJECTS):
                sv = saved.get(k) if isinstance(saved.get(k), dict) else {}
                db.execute('insert into subjects(key,name,short,pos) values(?,?,?,?)',
                           (k, (sv.get('name') or n).strip() or n, (sv.get('short') or sh).strip() or sh, i))
        if not db.execute("select 1 from users where lower(login)='admin'").fetchone():
            global FIRST_RUN_ADMIN_PW
            env_pw = os.environ.get('ALQA_ADMIN_PASSWORD')
            pw = env_pw if env_pw else gen_pw()
            if not env_pw:
                FIRST_RUN_ADMIN_PW = pw
            db.execute('insert into users(id,name,login,pw_hash,role,must_change,created_at) values(?,?,?,?,?,1,?)',
                       (str(uuid.uuid4()), 'Әкімші', 'admin', hash_pw(pw), 'admin', now_iso()))
        if not db.execute('select 1 from questions').fetchone():
            for s, t, o, c in SEED_Q:
                db.execute('insert into questions(id,subject,text,options,correct) values(?,?,?,?,?)',
                           (str(uuid.uuid4()), s, t, json.dumps(o, ensure_ascii=False), c))
    db.close()


# ------------------------------------------------------------------ helpers
def duration(db):
    r = db.execute("select value from settings where key='duration'").fetchone()
    try:
        return int(r['value']) if r else 15
    except Exception:
        return 15


def quiz_settings(db):
    def g(k, d):
        r = db.execute('select value from settings where key=?', (k,)).fetchone()
        return r['value'] if r else d
    try:
        per = int(g('per_subject', '0'))
    except Exception:
        per = 0
    return {'perSubject': max(0, per), 'shuffleOptions': g('shuffle_options', '0') == '1'}


def subjects(db):
    return [{'key': r['key'], 'name': r['name'], 'short': r['short']}
            for r in db.execute('select * from subjects order by pos, key')]


def subject_keys(db):
    return {r['key'] for r in db.execute('select key from subjects')}


def auth(db, token, role=None):
    r = db.execute('select u.* from sessions s join users u on u.id=s.user_id where s.token=? and s.expires_at>?',
                   (str(token or ''), time.time())).fetchone()
    if not r:
        raise ApiError('unauthorized')
    if r['status'] == 'blocked':
        raise ApiError('blocked')
    if role and r['role'] != role:
        raise ApiError('forbidden')
    return r


def user_json(r):
    return {'id': r['id'], 'name': r['name'], 'school': r['school'], 'grade': r['grade'], 'login': r['login'],
            'role': r['role'], 'status': r['status'], 'mustChange': bool(r['must_change']), 'created': r['created_at']}


def result_json(r):
    return {'id': r['id'], 'userId': r['user_id'], 'name': r['name'], 'school': r['school'], 'grade': r['grade'],
            'date': r['created_at'], 'score': r['score'], 'total': r['total'], 'pct': r['pct'],
            'time': r['time_sec'], 'subjects': json.loads(r['subjects'])}


def attempt_json(a):
    subs = []
    for s in json.loads(a['questions']):
        subs.append({'key': s['key'], 'name': s['name'],
                     'questions': [{k: v for k, v in q.items() if k != 'correct'} for q in s['questions']]})
    return {'attemptId': a['id'], 'elapsed': max(0, int(time.time() - a['started_at'])),
            'duration': a['duration_min'], 'subjects': subs}


def s(v):
    return v.strip() if isinstance(v, str) else ''


def is_int(v, lo, hi):
    return isinstance(v, int) and not isinstance(v, bool) and lo <= v <= hi


def create_student(db, name, school, grade, base):
    name, school = s(name), s(school)
    if len(name) < 3 or len(school) < 1 or len(name) > 120 or len(school) > 160 or grade not in GRADES:
        raise ApiError('invalid_input')
    b = ''.join(c for c in s(base).lower() if c in 'abcdefghijklmnopqrstuvwxyz0123456789')[:12] or 'user'
    login = None
    for _ in range(60):
        cand = b + str(100 + secrets.randbelow(900))
        if not db.execute('select 1 from users where lower(login)=?', (cand,)).fetchone():
            login = cand
            break
    if not login:
        raise ApiError('try_again')
    pw = gen_pw()
    uid = str(uuid.uuid4())
    db.execute('insert into users(id,name,school,grade,login,pw_hash,role,created_at) values(?,?,?,?,?,?,?,?)',
               (uid, name, school, grade, login, hash_pw(pw), 'student', now_iso()))
    return {'id': uid, 'name': name, 'login': login, 'password': pw}


# ------------------------------------------------------------------ public API
def register_student(db, a):
    return create_student(db, a.get('p_name'), a.get('p_school'), a.get('p_grade'), a.get('p_base'))


def login(db, a):
    lg = s(a.get('p_login')).lower()
    pw = a.get('p_password') if isinstance(a.get('p_password'), str) else ''
    db.execute('delete from login_fails where at < ?', (time.time() - 86400,))
    fails = db.execute('select count(*) c from login_fails where login=? and at>?', (lg, time.time() - 600)).fetchone()['c']
    if fails >= 8:
        return {'error': 'too_many'}
    u = db.execute('select * from users where lower(login)=?', (lg,)).fetchone()
    if not u or not check_pw(pw, u['pw_hash']):
        db.execute('insert into login_fails(login,at) values(?,?)', (lg, time.time()))
        return {'error': 'bad_credentials'}
    if u['status'] == 'blocked':
        return {'error': 'blocked'}
    db.execute('delete from login_fails where login=?', (lg,))
    db.execute('delete from sessions where expires_at < ?', (time.time(),))
    tok = str(uuid.uuid4())
    db.execute('insert into sessions(token,user_id,expires_at) values(?,?,?)',
               (tok, u['id'], time.time() + SESSION_DAYS * 86400))
    return {'token': tok, 'user': user_json(u)}


def logout(db, a):
    db.execute('delete from sessions where token=?', (str(a.get('p_token') or ''),))
    return None


def me(db, a):
    return user_json(auth(db, a.get('p_token')))


def get_duration(db, a):
    return duration(db)


def get_subjects(db, a):
    return subjects(db)


def get_quiz_settings(db, a):
    return quiz_settings(db)


# ------------------------------------------------------------------ student API
def test_info(db, a):
    auth(db, a.get('p_token'), 'student')
    counts = {x['key']: 0 for x in subjects(db)}
    for r in db.execute('select subject, count(*) c from questions group by subject'):
        if r['subject'] in counts:
            counts[r['subject']] = r['c']
    qz = quiz_settings(db)
    return {'duration': duration(db), 'counts': counts, 'perSubject': qz['perSubject'],
            'shuffleOptions': qz['shuffleOptions']}


def active_attempt(db, a):
    u = auth(db, a.get('p_token'), 'student')
    r = db.execute('select * from attempts where user_id=? and submitted=0 order by started_at desc limit 1', (u['id'],)).fetchone()
    return attempt_json(r) if r else None


def start_test(db, a):
    u = auth(db, a.get('p_token'), 'student')
    r = db.execute('select * from attempts where user_id=? and submitted=0 order by started_at desc limit 1', (u['id'],)).fetchone()
    if r:
        if time.time() < r['started_at'] + r['duration_min'] * 60:
            return attempt_json(r)
        db.execute('update attempts set submitted=1 where id=?', (r['id'],))
    subs = []
    qz = quiz_settings(db)
    per = qz['perSubject']
    for sj in subjects(db):
        key, name = sj['key'], sj['name']
        rows = list(db.execute('select * from questions where subject=? order by seq', (key,)))
        if per:
            # әр нұсқада кездейсоқ таңдау және кездейсоқ реттеу
            rows = RNG.sample(rows, per) if len(rows) > per else rows
            RNG.shuffle(rows)
        qs = []
        for q in rows:
            opts, cor = json.loads(q['options']), q['correct']
            if qz['shuffleOptions']:
                order = list(range(len(opts)))
                RNG.shuffle(order)
                opts = [opts[i] for i in order]
                cor = order.index(cor)
            qs.append({'id': q['id'], 'text': q['text'], 'options': opts, 'correct': cor})
        if qs:
            subs.append({'key': key, 'name': name, 'questions': qs})
    if not subs:
        raise ApiError('no_questions')
    aid = str(uuid.uuid4())
    db.execute('insert into attempts(id,user_id,started_at,duration_min,questions) values(?,?,?,?,?)',
               (aid, u['id'], time.time(), duration(db), json.dumps(subs, ensure_ascii=False)))
    return attempt_json(db.execute('select * from attempts where id=?', (aid,)).fetchone())


def submit_test(db, a):
    u = auth(db, a.get('p_token'), 'student')
    at = db.execute('select * from attempts where id=? and user_id=? and submitted=0', (str(a.get('p_attempt')), u['id'])).fetchone()
    if not at:
        raise ApiError('no_attempt')
    answers = a.get('p_answers') if isinstance(a.get('p_answers'), dict) else {}
    total = score = 0
    subs = []
    for sub in json.loads(at['questions']):
        c = 0
        for q in sub['questions']:
            ans = answers.get(q['id'])
            if isinstance(ans, str) and ans.isdigit():
                ans = int(ans)
            if is_int(ans, 0, 3) and ans == q['correct']:
                c += 1
        n = len(sub['questions'])
        subs.append({'key': sub['key'], 'name': sub['name'], 'score': c, 'total': n})
        total += n
        score += c
    spent = min(max(0, int(time.time() - at['started_at'])), at['duration_min'] * 60)
    pct = int(score * 100 / total + 0.5) if total else 0
    rid = str(uuid.uuid4())
    db.execute('insert into results(id,user_id,name,school,grade,score,total,pct,time_sec,subjects,created_at) values(?,?,?,?,?,?,?,?,?,?,?)',
               (rid, u['id'], u['name'], u['school'], u['grade'], score, total, pct, spent, json.dumps(subs, ensure_ascii=False), now_iso()))
    db.execute('update attempts set submitted=1 where id=?', (at['id'],))
    return result_json(db.execute('select * from results where id=?', (rid,)).fetchone())


def my_results(db, a):
    u = auth(db, a.get('p_token'), 'student')
    return [result_json(r) for r in db.execute('select * from results where user_id=? order by created_at desc', (u['id'],))]


# ------------------------------------------------------------------ admin API
def q_json(r):
    return {'id': r['id'], 'subject': r['subject'], 'text': r['text'], 'options': json.loads(r['options']), 'correct': r['correct']}


def valid_question(keys, subject, text, options, correct):
    return (subject in keys and s(text) != '' and isinstance(options, list) and len(options) == 4
            and all(isinstance(o, str) and o.strip() for o in options) and is_int(correct, 0, 3))


def admin_questions(db, a):
    auth(db, a.get('p_token'), 'admin')
    return [q_json(r) for r in db.execute('select * from questions order by seq')]


def admin_save_question(db, a):
    auth(db, a.get('p_token'), 'admin')
    sub, text, opts, cor = a.get('p_subject'), s(a.get('p_text')), a.get('p_options'), a.get('p_correct')
    if not valid_question(subject_keys(db), sub, text, opts, cor):
        raise ApiError('invalid_input')
    opts = [o.strip() for o in opts]
    qid = a.get('p_id')
    if not qid:
        db.execute('insert into questions(id,subject,text,options,correct) values(?,?,?,?,?)',
                   (str(uuid.uuid4()), sub, text, json.dumps(opts, ensure_ascii=False), cor))
    else:
        db.execute('update questions set subject=?,text=?,options=?,correct=? where id=?',
                   (sub, text, json.dumps(opts, ensure_ascii=False), cor, str(qid)))
    return None


def admin_import_questions(db, a):
    auth(db, a.get('p_token'), 'admin')
    items = a.get('p_items')
    if not isinstance(items, list):
        raise ApiError('invalid_input')
    added = skipped = 0
    keys = subject_keys(db)
    for it in items:
        if isinstance(it, dict) and valid_question(keys, it.get('subject'), it.get('text'), it.get('options'), it.get('correct')):
            db.execute('insert into questions(id,subject,text,options,correct) values(?,?,?,?,?)',
                       (str(uuid.uuid4()), it['subject'], s(it['text']),
                        json.dumps([o.strip() for o in it['options']], ensure_ascii=False), it['correct']))
            added += 1
        else:
            skipped += 1
    return {'added': added, 'skipped': skipped}


def admin_delete_question(db, a):
    auth(db, a.get('p_token'), 'admin')
    db.execute('delete from questions where id=?', (str(a.get('p_id')),))
    return None


def admin_students(db, a):
    auth(db, a.get('p_token'), 'admin')
    return [user_json(r) for r in db.execute("select * from users where role='student' order by created_at desc")]


def admin_create_student(db, a):
    auth(db, a.get('p_token'), 'admin')
    return create_student(db, a.get('p_name'), a.get('p_school'), a.get('p_grade'), a.get('p_base'))


def admin_reset_password(db, a):
    auth(db, a.get('p_token'), 'admin')
    t = db.execute("select * from users where id=? and role='student'", (str(a.get('p_user')),)).fetchone()
    if not t:
        raise ApiError('not_found')
    pw = gen_pw()
    db.execute('update users set pw_hash=? where id=?', (hash_pw(pw), t['id']))
    db.execute('delete from sessions where user_id=?', (t['id'],))
    return {'name': t['name'], 'login': t['login'], 'password': pw}


def admin_set_status(db, a):
    auth(db, a.get('p_token'), 'admin')
    st = a.get('p_status')
    if st not in ('active', 'blocked'):
        raise ApiError('invalid_input')
    uid = str(a.get('p_user'))
    db.execute("update users set status=? where id=? and role='student'", (st, uid))
    if st == 'blocked':
        db.execute('delete from sessions where user_id=?', (uid,))
    return None


def admin_delete_student(db, a):
    auth(db, a.get('p_token'), 'admin')
    db.execute("delete from users where id=? and role='student'", (str(a.get('p_user')),))
    return None


def admin_results(db, a):
    auth(db, a.get('p_token'), 'admin')
    return [result_json(r) for r in db.execute('select * from results order by created_at desc')]


def admin_change_password(db, a):
    u = auth(db, a.get('p_token'), 'admin')
    cur, new = a.get('p_current'), a.get('p_new')
    if not isinstance(cur, str) or not check_pw(cur, u['pw_hash']):
        raise ApiError('bad_password')
    if not isinstance(new, str) or len(new) < 6:
        raise ApiError('weak_password')
    db.execute('update users set pw_hash=?, must_change=0 where id=?', (hash_pw(new), u['id']))
    return None


def admin_set_duration(db, a):
    auth(db, a.get('p_token'), 'admin')
    m = a.get('p_minutes')
    if not is_int(m, 1, 180):
        raise ApiError('invalid_input')
    db.execute("insert into settings(key,value) values('duration',?) on conflict(key) do update set value=excluded.value", (str(m),))
    return None


def check_names(items):
    names = [v['name'].strip().lower() for v in items]
    if len(set(names)) != len(names):
        raise ApiError('duplicate_name')


def clean_subject(name, short):
    name, short = s(name), s(short)
    if not short:
        short = name[:30]
    if not (1 <= len(name) <= 80) or not (1 <= len(short) <= 30):
        raise ApiError('invalid_input')
    return name, short


def admin_set_quiz(db, a):
    auth(db, a.get('p_token'), 'admin')
    per, sh = a.get('p_per_subject'), a.get('p_shuffle_options')
    if not is_int(per, 0, 500) or not isinstance(sh, bool):
        raise ApiError('invalid_input')
    up = "insert into settings(key,value) values(?,?) on conflict(key) do update set value=excluded.value"
    db.execute(up, ('per_subject', str(per)))
    db.execute(up, ('shuffle_options', '1' if sh else '0'))
    return None


def admin_set_subjects(db, a):
    auth(db, a.get('p_token'), 'admin')
    items = a.get('p_subjects')
    if not isinstance(items, list):
        raise ApiError('invalid_input')
    cur = {x['key']: x for x in subjects(db)}
    for it in items:
        if not isinstance(it, dict) or it.get('key') not in cur:
            raise ApiError('invalid_input')
        name, short = clean_subject(it.get('name'), it.get('short'))
        cur[it['key']] = {'key': it['key'], 'name': name, 'short': short}
    check_names(list(cur.values()))
    for v in cur.values():
        db.execute('update subjects set name=?, short=? where key=?', (v['name'], v['short'], v['key']))
    return None


def admin_add_subject(db, a):
    auth(db, a.get('p_token'), 'admin')
    name, short = clean_subject(a.get('p_name'), a.get('p_short'))
    cur = subjects(db)
    if len(cur) >= MAX_SUBJECTS:
        raise ApiError('too_many_subjects')
    check_names(cur + [{'name': name}])
    key = 's' + secrets.token_hex(4)
    pos = (db.execute('select coalesce(max(pos), -1) m from subjects').fetchone()['m']) + 1
    db.execute('insert into subjects(key,name,short,pos) values(?,?,?,?)', (key, name, short, pos))
    return {'key': key}


def admin_delete_subject(db, a):
    auth(db, a.get('p_token'), 'admin')
    key = str(a.get('p_key'))
    cur = subject_keys(db)
    if key not in cur:
        raise ApiError('not_found')
    if len(cur) <= 1:
        raise ApiError('last_subject')
    n = db.execute('select count(*) c from questions where subject=?', (key,)).fetchone()['c']
    db.execute('delete from questions where subject=?', (key,))
    db.execute('delete from subjects where key=?', (key,))
    return {'deletedQuestions': n}


def admin_move_subject(db, a):
    auth(db, a.get('p_token'), 'admin')
    key, d = str(a.get('p_key')), a.get('p_dir')
    keys = [x['key'] for x in subjects(db)]
    if key not in keys or d not in ('up', 'down'):
        raise ApiError('invalid_input')
    i = keys.index(key)
    j = i - 1 if d == 'up' else i + 1
    if 0 <= j < len(keys):
        keys[i], keys[j] = keys[j], keys[i]
        for pos, k in enumerate(keys):
            db.execute('update subjects set pos=? where key=?', (pos, k))
    return None


FUNCS = {f.__name__: f for f in (
    register_student, login, logout, me, get_duration, get_subjects, get_quiz_settings, test_info, active_attempt, start_test, submit_test, my_results,
    admin_questions, admin_save_question, admin_import_questions, admin_delete_question, admin_students,
    admin_create_student, admin_reset_password, admin_set_status, admin_delete_student, admin_results,
    admin_change_password, admin_set_duration, admin_set_subjects,
    admin_add_subject, admin_delete_subject, admin_move_subject, admin_set_quiz)}


# ------------------------------------------------------------------ HTTP
class Handler(BaseHTTPRequestHandler):
    server_version = 'Alqa'

    def log_message(self, fmt, *args):
        pass

    def _send(self, code, body=b'', ctype='application/json; charset=utf-8'):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(body)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode('utf-8'))

    def do_GET(self):
        path = self.path.split('?')[0]
        if path in ('/', '/index.html'):
            try:
                with open(INDEX, 'rb') as f:
                    self._send(200, f.read(), 'text/html; charset=utf-8')
            except OSError:
                self._send(500, 'index.html табылмады. Ол server.py жанында болуы керек.'.encode('utf-8'), 'text/plain; charset=utf-8')
        elif path == '/favicon.ico':
            self._send(204)
        else:
            self._send(404, b'Not found', 'text/plain')

    do_HEAD = do_GET

    def do_POST(self):
        path = self.path.split('?')[0]
        if not path.startswith('/api/') or path[5:] not in FUNCS:
            return self._json(404, {'message': 'not_found'})
        try:
            n = int(self.headers.get('Content-Length') or 0)
        except ValueError:
            n = 0
        if n > 2_000_000:
            return self._json(413, {'message': 'invalid_input'})
        try:
            args = json.loads(self.rfile.read(n) or b'{}')
            if not isinstance(args, dict):
                raise ValueError
        except ValueError:
            return self._json(400, {'message': 'invalid_input'})
        db = connect()
        try:
            with db:
                result = FUNCS[path[5:]](db, args)
            self._json(200, result)
        except ApiError as e:
            self._json(400, {'message': str(e)})
        except (KeyError, TypeError, ValueError, AttributeError, IndexError):
            traceback.print_exc()
            self._json(400, {'message': 'invalid_input'})
        except Exception:
            traceback.print_exc()
            self._json(500, {'message': 'server_error'})
        finally:
            db.close()


def lan_ips():
    ips = set()
    try:
        sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sk.connect(('10.255.255.255', 1))
        ips.add(sk.getsockname()[0])
        sk.close()
    except Exception:
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            ips.add(ip)
    except Exception:
        pass
    return sorted(i for i in ips if not i.startswith('127.'))


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    args = [a for a in sys.argv[1:]]
    init_db()
    if '--reset-admin' in args:
        db = connect()
        pw = os.environ.get('ALQA_ADMIN_PASSWORD') or gen_pw()
        with db:
            db.execute("update users set pw_hash=?, must_change=1, status='active' where lower(login)='admin'", (hash_pw(pw),))
            db.execute("delete from sessions where user_id in (select id from users where lower(login)='admin')")
        db.close()
        print('Әкімшінің жаңа уақытша паролі: admin / %s' % pw)
        print('Кіргеннен кейін «Баптаулар» бөлімінде парольді ауыстырыңыз.')
        return
    try:
        port = int(os.environ.get('PORT') or 8000)
    except ValueError:
        port = 8000
    for a in args:
        if a.isdigit():
            port = int(a)
    try:
        srv = ThreadingHTTPServer((os.environ.get('ALQA_HOST') or '0.0.0.0', port), Handler)
    except OSError as e:
        print('Серверді іске қосу мүмкін болмады (%s). Порт бос емес болуы мүмкін: python server.py 8080' % e)
        sys.exit(1)
    srv.daemon_threads = True
    print('=' * 60)
    print(' Alqa сервері іске қосылды (интернет қажет емес)')
    print('=' * 60)
    print(' Осы компьютерден:   http://localhost:%d' % port)
    for ip in lan_ips():
        print(' Басқа құрылғылардан: http://%s:%d' % (ip, port))
    if FIRST_RUN_ADMIN_PW:
        print(' ' + '-' * 58)
        print(' АЛҒАШҚЫ ӘКІМШІ ПАРОЛІ (тек бір рет көрсетіледі, жазып алыңыз):')
        print('     логин: admin      пароль: %s' % FIRST_RUN_ADMIN_PW)
        print(' Кіргеннен кейін «Баптаулар» бөлімінде парольді ауыстырыңыз.')
        print(' ' + '-' * 58)
    else:
        print(' Әкімші логині: admin (парольді ұмытсаңыз: python server.py --reset-admin)')
    print(' Деректер файлы:     %s' % DB_PATH)
    print(' Тоқтату: Ctrl+C немесе осы терезені жабыңыз')
    print('=' * 60)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print('\nСервер тоқтатылды.')


if __name__ == '__main__':
    main()
