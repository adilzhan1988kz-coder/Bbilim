#!/usr/bin/env python3
"""Серверді соңынан-соңына тексеретін қысқа тест (тек стандартты кітапхана)."""
import json, os, subprocess, sys, tempfile, time, socket, urllib.request, urllib.error

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ADMIN_PW = 'TestAdmin1'


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


PORT = free_port()
BASE = 'http://127.0.0.1:%d' % PORT
OK = True


def check(name, cond):
    global OK
    print(('PASS ' if cond else 'FAIL ') + name)
    OK = OK and bool(cond)


def api(fn, **args):
    req = urllib.request.Request(BASE + '/api/' + fn, data=json.dumps(args).encode(), method='POST')
    try:
        raw = urllib.request.urlopen(req).read()
        return json.loads(raw or b'null')
    except urllib.error.HTTPError as e:
        return {'__error': json.loads(e.read())['message']}


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, PORT=str(PORT), ALQA_DB=os.path.join(tmp, 'test.db'), ALQA_ADMIN_PASSWORD=ADMIN_PW)
    proc = subprocess.Popen([sys.executable, os.path.join(ROOT, 'server.py')], env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(50):
            try:
                urllib.request.urlopen(BASE + '/', timeout=1)
                break
            except Exception:
                time.sleep(0.2)
        check('басты бет ашылады', b'Alqa' in urllib.request.urlopen(BASE + '/').read())

        # оқушы: тіркелу, кіру, тест
        reg = api('register_student', p_name='Айдар Серіков', p_school='№1', p_grade='7-сынып', p_base='aydar')
        check('7-сыныпты оқушы тіркелді', reg.get('login', '').startswith('aydar') and len(reg.get('password', '')) == 8)
        check('қате пароль қабылданбайды', api('login', p_login=reg['login'], p_password='x').get('error') == 'bad_credentials')
        tok = api('login', p_login=reg['login'], p_password=reg['password'])['token']
        check('оқушы әкімші функциясын шақыра алмайды', api('admin_results', p_token=tok).get('__error') == 'forbidden')
        att = api('start_test', p_token=tok)
        check('тест 3 пәннен басталды', len(att['subjects']) == 3)
        check('дұрыс жауаптар оқушыға жіберілмейді', '"correct"' not in json.dumps(att))
        res = api('submit_test', p_token=tok, p_attempt=att['attemptId'], p_answers={})
        check('жауапсыз тест 0 ұпай', res['score'] == 0 and res['total'] == 15)

        # әкімші
        adm = api('login', p_login='admin', p_password=ADMIN_PW)
        at = adm['token']
        check('әкімші кірді', adm['user']['role'] == 'admin' and adm['user']['mustChange'] is True)
        key = api('admin_add_subject', p_token=at, p_name='Физика', p_short='Физ')['key']
        items = [{'subject': key, 'text': 'Сұрақ %d' % i, 'options': ['a', 'b', 'c', 'd'], 'correct': i % 4} for i in range(10)]
        check('10 сұрақ импортталды', api('admin_import_questions', p_token=at, p_items=items)['added'] == 10)
        api('admin_set_quiz', p_token=at, p_per_subject=4, p_shuffle_options=True)
        a1 = api('start_test', p_token=tok)
        phys = [s for s in a1['subjects'] if s['name'] == 'Физика'][0]['questions']
        check('пәннен 10-нан 4 сұрақ кездейсоқ берілді', len(phys) == 4)
        api('submit_test', p_token=tok, p_attempt=a1['attemptId'], p_answers={})
        check('пәнді өшіргенде оның сұрақтары да өшеді',
              api('admin_delete_subject', p_token=at, p_key='math').get('deletedQuestions') == 5)
        check('пароль ауыстырылды', api('admin_change_password', p_token=at, p_current=ADMIN_PW, p_new='NewPass123') is None)
        check('жаңа пароль жұмыс істейді', 'token' in api('login', p_login='admin', p_password='NewPass123'))
        check('ескі пароль жұмыс істемейді', api('login', p_login='admin', p_password=ADMIN_PW).get('error') == 'bad_credentials')
    finally:
        proc.terminate()
        try:
            proc.wait(5)
        except Exception:
            proc.kill()
    print('\nНӘТИЖЕ:', 'БӘРІ ДҰРЫС' if OK else 'ҚАТЕЛЕР БАР')
    sys.exit(0 if OK else 1)


if __name__ == '__main__':
    main()
