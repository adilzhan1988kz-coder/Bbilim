@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py server.py
  goto end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python server.py
  goto end
)
echo Python табылмады. python.org сайтынан орнатыңыз ("Add Python to PATH" белгісін қойыңыз).
:end
pause
